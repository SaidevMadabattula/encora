export class UserModel{
    UserName!: string;
    Password!:string;
}