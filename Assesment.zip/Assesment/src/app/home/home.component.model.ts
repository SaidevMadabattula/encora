export class ContactPersonModel{
  name : string = "";
  country : string = "";
  phone : number =  0o0;
  companyId : number = 0;
  id : number = 0;
}